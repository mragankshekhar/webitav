<?php
ob_start();
@session_start();
$varAdminFolder = "ms-administration";
//https://p3nwvpweb149.shr.prod.phx3.secureserver.net:8443/login_up.php3
if ($_SERVER["SERVER_NAME"] === "mssinfotech.in" || $_SERVER["SERVER_NAME"] === "www.mssinfotech.in") {
    $mysql_user = 'mssinifn_itav'; //'ms2fun';
    $password = "123@qwe";
    $database_host = "localhost";
    $database = "mssinifn_itav";
    define("DIRECTORY", "/itav/");
    define("URL_ROOT", "http://www.mssinfotech.in" . DIRECTORY);
} else {
    $mysql_user = 'root'; //'ms2fun';
    $password = ''; //"123@qwe";
    $database_host = "localhost";
    $database = "payFee";
    define("DIRECTORY", "/MVP/api/");
    define("URL_ROOT", "http://localhost" . DIRECTORY);
}
$table_prefix = "mss_";
define("TABLE_PREFIX", $table_prefix);
define("DS", DIRECTORY_SEPARATOR);
define("PATH_ROOT", dirname(__FILE__));
define("PATH_LIB", PATH_ROOT . DS . "function" . DS);
include_once PATH_ROOT . DS . 'autoloader.php';

ini_set( "short_open_tag", 1 );
$db = new MySqlDb($database_host, $mysql_user, $password, $database);

/* * ************************-----setup my framework start-------********************** */
$theme = "version";
$mss = new mss($theme);
$mss->set_error(false);
$mss->setReporting();
$visit=$mss->addVisit(true);
/* * ************************-----setup my framework start-------********************** */
require_once(PATH_LIB . 'mailer/PHPMailerAutoload.php');
require_once(PATH_LIB . "table.php");
require_once(PATH_LIB . "functions.php");

$LinksDetails = fetchSetting();
//echo "<pre>";print_r($LinksDetails);exit;
$lang = '';
if (isset($_GET['lang']) && $_GET['lang'] != "") {
    $lang = $_GET['lang'];
    $_SESSION['lang'] = $lang;
    setcookie('lang', $lang, time() + (3600 * 24 * 30));
} else if (isset($_SESSION['lang']) && $_SESSION['lang'] != "") {
    //echo "hoooelll";print_r($_SESSION);exit;
    $lang = $_SESSION['lang'];
    $_SESSION['lang'] = $lang;
    //echo "hoooelll";print_r($_SESSION);exit;
} else if (isset($_COOKIE['lang']) && $_COOKIE['lang'] != "") {
    $lang = $_COOKIE['lang'];
    $_SESSION['lang'] = $_COOKIE['lang'];
} else {
    $lang = 'en';
    $_SESSION['lang'] = $lang;
}
require_once(PATH_ROOT . DS . "language" . DS . $lang . ".php");
/* * *** get userid and password from cookies ******* */
$cur = "";
if (isset($_GET["cur"]) && $_GET["cur"] != "") {
    $cur = $_GET["cur"];
    $_SESSION["cur"] = $cur;
} elseif (isset($_SESSION["cur"]) && $_SESSION["cur"] != "") {
    $cur = $_SESSION["cur"];
    $_SESSION["cur"] = $cur;
    setcookie('cur', $cur, time() + (3600 * 24 * 30));
} else if (isset($_COOKIE['cur']) && $_COOKIE['cur'] != "") {
    $cur = $_COOKIE['cur'];
    $_SESSION['cur'] = $_COOKIE['cur'];
} else {
    $cur = $LinksDetails["currency_code"];
    $_SESSION["cur"] = $cur;
}

/* * ***********currency connect************ */
include("constent.php");
$includedFile = "";
$pageData = $data = $alert_err = array();
