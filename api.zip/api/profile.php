<?php
include("../config.php");
$ch = strtolower($_REQUEST["type"]);
if($ch== "fetch-profile") {
	$status=array();
	$sqlUserArray = array($_REQUEST["uid"], $_REQUEST["uid"], md5($_REQUEST["pass"]));
	$ids = $db->getRow("select * from  " . SITE_USER . " where (username =? or email=?) and pass=? and status=1", $sqlUserArray);
	if (is_array($ids) && count($ids) > 0){	
		$status=$ids;
		$status["status"]="success";
	} else {
		$status["status"]="error";
		$status["message"]="invalid Userid or password ".$id;
	} 
	echo json_encode($status);
	exit;
}
else{
	echo json_encode(array("status" => "error", "action" => "default-" . $ch, "request" => $_POST, "msg" => "please check you ajax request type is not define in form"));
}