<?php
define("SITE_USER", TABLE_PREFIX . "site_user");
define("SETTINGS", TABLE_PREFIX . "settings");
define("NO_VISIT", TABLE_PREFIX . "no_visit");
define("PUSH_NOTIFICATION", TABLE_PREFIX . "push_notification");
define("CMS", TABLE_PREFIX . "cms");

define("MAILMSG", TABLE_PREFIX . "mailmsg");
define("ROLL", TABLE_PREFIX . "roll");
define("MENUS", TABLE_PREFIX . "menus");
define("PRIVILAGES", TABLE_PREFIX . "privilages");
define("MAIL_HISTORY", TABLE_PREFIX . "email_history");
define("LOGIN_HISTORY", TABLE_PREFIX . "login_history");
define("LANGUAGE", TABLE_PREFIX . "language");
define("SMS_HISTORY", TABLE_PREFIX . "sms_history");
?>