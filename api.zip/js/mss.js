// JavaScript Document
var mssApp = angular.module('mssApp', ['ngRoute']);

mssApp.factory("services", ['$http', function($http) {
  var serviceBase = 'module/'
    var obj = {};
    obj.getCustomer = function(page,parama){
        return $http.get(serviceBase + page + "?" + parama);
    }
    return obj;   
}]);

// configure our routes
mssApp.config(function($routeProvider) {
    $routeProvider
    // route for the home page
    .when('/', {
            templateUrl : 'view/index.html',
            controller  : 'mainController'
    })
	.when('/service', {
            templateUrl : 'view/service.html',
            controller  : 'serviceController'
    })
	.when('/about', {
            templateUrl : 'view/about.html',
            controller  : 'aboutController'
    })
	.when('/faq', {
            templateUrl : 'view/faq.html',
            controller  : 'faqController'
    })
    .when('/setting', {
            templateUrl : 'view/setting.php',
            controller  : 'settingController'
    })
	.when('/feedback', {
            templateUrl : 'view/feedback.html',
            controller  : 'feedbackController'
    })
	.when('/privedy_policy', {
            templateUrl : 'view/terms_of_uses.html',
            controller  : 'terms_of_usesController'
    });
});

// create the controller and inject Angular's $scope
mssApp.controller('mainController', function($scope,services) {
	$scope.message = 'Everyone come and see how good I look!';
});
mssApp.controller('serviceController', function($scope,services) {
	$scope.message = 'Everyone come and see how good I look!';
});
mssApp.controller('aboutController', function($scope,services) {
	$scope.message = 'Everyone come and see how good I look!';
});
mssApp.controller('faqController', function($scope,services) {
	$scope.message = 'Everyone come and see how good I look!';
});
mssApp.controller('settingController', function($scope,services) {
	$scope.message = 'Everyone come and see how good I look!';
});
mssApp.controller('feedbackController', function($scope,services) {
	$scope.message = 'Everyone come and see how good I look!';
});
mssApp.controller('terms_of_usesController', function($scope,services) {
	$scope.message = 'Everyone come and see how good I look!';
});
/*
mssApp.controller('cmsController', function($scope, services) {
    services.getCustomer("cms.php","type=view").then(function(data){
        $scope.contents = data.data;
    });
});
*/

$(".ms-link").on("touchend click",function(){
	$("#ms-slidebar").css({"margin-left":"-300px"}).removeClass("sb-active");
	$("html").removeClass("sb-active sb-active-left");
	url=ROOT+"#/"+$(this).attr("data-href")
	window.location=url;
	return true;
})
