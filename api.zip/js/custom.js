// JavaScript Document
$(document).ready(function(){
	var progressbar     = $("#progressbar"),
		statustxt       = $("#progresstext"),
		submitbutton    = $("#submit"),
		myform          = $(".form_ajax"),
		title			= document.title,
		progressDiv     = $("#progressDiv"),
		completed       = "0%";
	$(myform).ajaxForm({
		beforeSend: function() { //brfore sending form
			submitbutton.attr('disabled', ''); // disable upload button
			progressDiv.show();
			document.title = " Processing Please wait...";
			progressbar.width(completed);
		},
		uploadProgress: function(event, position, total, percentComplete) { //on progress
			$("#progress").width(percentComplete + '%');//update progressbar percent complete
			//$(".statustxt").html(percentComplete + '% completed'); //update status text
			//addNotice(percentComplete+ "% Completed...", "fa fa-refresh", "");
			document.title = percentComplete+ "% Completed...";
			//submitbutton.html(percentComplete+' % Processing...');
		},
		complete: function(response) { // on complete
			//x$.gritter.removeAll();
			document.title = title;
			submitbutton.removeAttr('disabled'); //enable submit button
			progressDiv.slideUp(); // hide progressbar
			var data=(response.responseText).split("==>");
			if(data.status=="success"){
				if(data.type=="alert"){
					Android.showToast(data.msg)
				}
				else if(data.type=="image"){
					Android.showToast(data.msg);
					$("#"+data.imgid).attr("src",data.imgurl);
				}
				else if(data.type=="div"){
					$("#"+data.divid).html(data.msg);
				}
				else if(data.type=="url"){
					Android.showToast(data.msg);
					setInterval(function(){ window.location=data.url; }, 2000);
				}else if(data.type=="popup"){
					Android.showToast(data.msg);
				}else{
					Android.showToast(data.msg);
				}	
				resetbutton.click();
			}
			else if(data.status=="error"){
				Android.showToast(data.msg);
			}
		}
	});
	
})