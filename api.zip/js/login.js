// JavaScript Document
$(document).ready(function(){
	$("#loginBTN").on("click",function(){
		var uname=$("#ms-form-user").val();
		var pass=$("#ms-form-pass").val();
		if(uname==""){
			Android.showToast("Please enter user name");
		}else if(pass==""){
			Android.showToast("Please enter Password");
		}else{
			login(uname,pass);
		}
	});
});
function login(uname,pass){
	$.getJSON(URL_ROOT+"login.php?type=login&uname="+uname+"&pass="+pass, function(data){
        Android.showToast(data.message);
		if(data.state=="success"){
			Android.saveUser(data.id,uname,pass,data.avatar,data.fullname);
			window.location='index.html';
		}
    });
}