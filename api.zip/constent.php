<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

define('PAGE_PER_NO', 6);
define("URL_IMAGES", URL_ROOT . "images/");

define("PATH_ADMIN", URL_ROOT . $varAdminFolder . "/");
//echo PATH_ADMIN;exit;
define("ADMIN_JS", PATH_ADMIN . "js/");
define("ADMIN_CSS", PATH_ADMIN . "css/");
define("URL_ADMIN_IMGAGES", URL_ROOT . "assets/");

/* * ***********mss connect************ */
define('API_KEY', 'mss123456789demo');
//echo @file_get_contents("http://mssinfotech.com/?action=".$_SERVER["HTTP_HOST"]);
/* * ***********mss config for email and connect************ */
//*********** Constent for define image ****************//
define("IMG", URL_ROOT . "function/timthumb.php?src=");
//************ Constent for define image *********//
if (isset($LinksDetails["mail_Username"]) && $LinksDetails["mail_Username"] != "") {
    define('MAIL_USERNAME', $LinksDetails["mail_Username"]);
}
if (isset($LinksDetails["mail_Password"]) && $LinksDetails["mail_Password"] != "") {
    define('MAIL_PASSWORD', $LinksDetails["mail_Password"]);
}
if (isset($LinksDetails["mail_sender_name"]) && $LinksDetails["mail_sender_name"] != "") {
    define('MAIL_SENDER_NAME', $LinksDetails["mail_sender_name"]);
}
if (isset($LinksDetails["mail_sender_email"]) && $LinksDetails["mail_sender_email"] != "") {
    define('MAIL_SENDER_EMAIL', $LinksDetails["mail_sender_email"]);
}
if (isset($LinksDetails["mail_SMTPSecure"]) && $LinksDetails["mail_SMTPSecure"] != "") {
    define('MAIL_SMTPSECURE', $LinksDetails["mail_SMTPSecure"]);
}
if (isset($LinksDetails["mail_Host"]) && $LinksDetails["mail_Host"] != "") {
    define('MAIL_HOST', $LinksDetails["mail_Host"]);
}
if (isset($LinksDetails["mail_Port"]) && $LinksDetails["mail_Port"] != "") {
    define('MAIL_PORT', $LinksDetails["mail_Port"]);
}

define("URL_ADMIN", URL_ROOT . $varAdminFolder . "/");
define("URL_ADMIN_HOME", URL_ADMIN . "index.php");
define("URL_ADMIN_CSS", URL_ADMIN . "css/");
define("URL_ADMIN_JS", URL_ADMIN . "js/");






define("URL_ADMIN_IMG", URL_ADMIN . "images/");
define("SELF", basename($_SERVER['PHP_SELF']));
define("PAGE_NAME", strtolower(basename($_SERVER['REQUEST_URI'])));
define("PATH_UPLOAD", PATH_ROOT . DS . "uploads" . DS);
define("PATH_MEDIA", PATH_UPLOAD . DS . "media" . DS);
define("PATH_UPLOAD_PHOTO", PATH_UPLOAD . "images" . DS);
define("ROOT", URL_ROOT . "templates/" . $mss->theme() . "/");
